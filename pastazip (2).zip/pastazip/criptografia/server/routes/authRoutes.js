const express = require('express');
const { loginPage, login, senha } = require('../controllers/authController'); // Garantir que as funções estão importadas

const router = express.Router();

// Rota para exibir o formulário de login (pedindo email)
router.get('/', loginPage); // Página de login

// Rota de verificação do login (pedindo senha após receber o email)
router.get('/login', login); // Rota para enviar email

router.get('/senha', senha);  // Rota para exibir página de senha

module.exports = router;
