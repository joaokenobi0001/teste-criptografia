const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const authRoutes = require('./routes/authRoutes'); // Verifique se o caminho está correto

dotenv.config();

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json()); // Para parsear JSON no corpo das requisições

// Rota para a página inicial (home)
app.get('/', (req, res) => {
  res.send('Bem-vindo à página inicial!');
});

// Rota de autenticação
app.use('/auth', authRoutes);  // Prefixa as rotas de autenticação com /auth

app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});

