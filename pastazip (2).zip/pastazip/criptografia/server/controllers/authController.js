const nodemailer = require('nodemailer');

// Função para enviar email
const enviarEmail = async (email) => {
  // Criação do transporte com as credenciais do Gmail
  let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL,   // Defina o seu email no .env
      pass: process.env.PASSWORD // Defina sua senha ou token de app no .env
    }
  });

  // Defina o conteúdo do email
  let info = await transporter.sendMail({
    from: process.env.EMAIL,  // Seu email de remetente
    to: email,                // Email do destinatário (usuário que preencheu o formulário)
    subject: 'Confirmação de Login',
    text: 'Você está tentando fazer login no nosso sistema. Se não foi você, por favor, ignore este email.'
  });

  console.log('Email enviado: %s', info.messageId);
};

// Função que exibe o formulário de login
const loginPage = (req, res) => {
  res.sendFile('login.html', { root: 'public' });  // Exibe a página de login
};

// Função que processa o login
const login = async (req, res) => {
  const { email } = req.query;

  // Validar se o email é válido (opcional, pode ser uma consulta ao banco de dados)
  if (!email || !email.includes('@')) {
    return res.status(400).send("Por favor, insira um email válido.");
  }

  // Enviar o email de confirmação
  try {
    await enviarEmail(email);
    res.send(`<h1>Email enviado para ${email}!</h1><p>Por favor, verifique sua caixa de entrada.</p>`);
  } catch (error) {
    console.error("Erro ao enviar email:", error);
    res.status(500).send("Erro ao tentar enviar o email.");
  }
};

// Função que exibe a página de senha
const senha = (req, res) => {
  res.sendFile('senha.html', { root: 'public' });  // Exibe a página de senha
};

module.exports = {
  loginPage,
  login,
  senha
};
