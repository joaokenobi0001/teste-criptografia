CREATE DATABASE nome_do_seu_banco;
CREATE USER seu_usuario WITH ENCRYPTED PASSWORD 'sua_senha';
GRANT ALL PRIVILEGES ON DATABASE nome_do_seu_banco TO seu_usuario;
