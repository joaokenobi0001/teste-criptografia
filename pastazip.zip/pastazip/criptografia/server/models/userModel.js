// models/userModel.js
const bcrypt = require('bcrypt');
const db = require('../config/db');


// Função para criar um novo usuário
const criarUsuario = async (email, senha) => {
  try {
    const hashedSenha = await bcrypt.hash(senha, 10);
    await pool.query(
      'INSERT INTO usuarios (email, senha) VALUES ($1, $2)',
      [email, hashedSenha]
    );
    console.log('Usuário criado com sucesso');
  } catch (error) {
    console.error('Erro ao criar usuário:', error);
    throw error; // re-lançar o erro para tratamento posterior
  }
};

module.exports = {
  criarUsuario,
};
