// server/utils/emailService.js
const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const enviarCodigoAcesso = async (email, codigoAcesso) => {
  await transporter.sendMail({
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'Seu Código de Acesso',
    text: `Seu código de acesso é: ${codigoAcesso}`,
  });
};

module.exports = enviarCodigoAcesso;
