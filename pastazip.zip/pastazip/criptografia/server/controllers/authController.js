// server/controllers/authController.js
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { criarUsuario, obterUsuarioPorEmail, atualizarCodigoAcesso } = require('../models/userModel');
const enviarCodigoAcesso = require('../utils/emailService');
require('dotenv').config();

const login = async (req, res) => {
  const { email, senha } = req.body;
  const usuario = await obterUsuarioPorEmail(email);

  if (!usuario || !(await bcrypt.compare(senha, usuario.senha))) {
    return res.status(401).send('Credenciais inválidas');
  }

  const codigoAcesso = Math.floor(100000 + Math.random() * 900000).toString();
  await atualizarCodigoAcesso(email, codigoAcesso);
  await enviarCodigoAcesso(email, codigoAcesso);

  res.send('Código de acesso enviado para o seu e-mail');
};

const verificarCodigo = async (req, res) => {
  const { email, codigoAcesso } = req.body;
  const usuario = await obterUsuarioPorEmail(email);

  if (!usuario || usuario.codigo_acesso !== codigoAcesso) {
    return res.status(401).send('Código de acesso inválido');
  }

  const token = jwt.sign({ id: usuario.id, email: usuario.email }, process.env.JWT_SECRET, {
    expiresIn: '1h',
  });
  res.json({ token });
};

module.exports = { login, verificarCodigo };
