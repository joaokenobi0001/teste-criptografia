// server/routes/authRoutes.js
const express = require('express');
const { login, verificarCodigo } = require('../controllers/authController');

const router = express.Router();

router.post('/login', login);
router.post('/verify', verificarCodigo);

module.exports = router;
